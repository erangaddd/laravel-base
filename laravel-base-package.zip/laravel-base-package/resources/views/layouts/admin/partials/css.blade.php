<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/jquery-ui@1.13.2/themes/base/theme.min.css" >
<link rel="stylesheet" type="text/css" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/material-colors@1.2.6/dist/colors.min.css">
<link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css"  href="https://cdn.datatables.net/buttons/1.4.0/css/buttons.dataTables.min.css" />
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/variables.css')}}">
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/icofont.css')}}">
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/themify.css')}}">
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/bootstrap.css')}}">
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/app.css')}}" >
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/color-2.css')}}">
<link rel="stylesheet" type="text/css" href="{{assetVersioned('css/responsive.css')}}">

